function searchit() {
    document.getElementById("hp").href = (("https://www.google.com/search?q=") + "Clinic for diabetes in " + (document.getElementById("linkit").value));
}